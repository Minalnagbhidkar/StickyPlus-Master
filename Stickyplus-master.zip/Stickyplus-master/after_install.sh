#!/bin/bash

echo "Running after install script...."

# Navigate to the application directory
cd /home/ubuntu/Stickynote-Upgrade

# Install the dependencies listed in package.json
npm install

echo "Dependencies installed successfully."
